# Proje Başlatma ve Çalıştırma

### https://www.youtube.com/watch?v=CgkZ7MvWUAA

--> İlk olarak REACTAPP ana dizini içerisinde konsolda aşağıdaki komutu çalıştırmalısın

- npm create vite@latest

-> Komutu çalıştırdıktan sonra gerekli ayarları konsoldan yapman gerekiyor

- cd my-react-app

- npm install

- npm run dev

--> npm run dev, npm start gibi çalışmakta ve ilgili dosyada bulunan projeyi run etmekte

--> Sonrasında program http://localhost:5173/ üzerinde çalışmaya hazır olacaktır.
